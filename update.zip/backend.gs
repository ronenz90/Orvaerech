// Backend for the "Or VaErech LeNaama" site (Google Apps Script).
// 1. Stores the site content (rows, links, texts) in a Drive file.
// 2. Saving requires the admin password, kept as the Script Property ADMIN_PASSWORD (not in this code).
// 3. Serves the gallery: all images in FOLDER_ID and all its sub-folders.
// After pasting: Project Settings -> Script properties -> add ADMIN_PASSWORD.
// Then: Deploy -> Manage deployments -> pencil -> Version: New version -> Deploy.

var FOLDER_ID = '16m87owSSRfjEpgxak8I286BvqwfnTH57';   // gallery images folder
var DATA_FILE_NAME = 'naama-site-data.json';           // created in My Drive, holds the site content
var MAX_FAILS = 8;                                     // wrong attempts before lockout
var LOCK_SECONDS = 900;                                // lockout duration (15 minutes)

// ---- entry points ----

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.action === 'site') return out_({ ok: true, data: readSite_() });
  return gallery_(p);
}

function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); }
  catch (err) { return out_({ ok: false, error: 'bad_request' }); }

  const auth = checkPassword_(req.password);
  if (auth !== 'ok') return out_({ ok: false, error: auth });

  if (req.action === 'login') return out_({ ok: true });

  if (req.action === 'save') {
    let clean;
    try { clean = sanitize_(req.data); }
    catch (err) { return out_({ ok: false, error: 'invalid_data', detail: String(err) }); }
    writeSite_(clean);
    return out_({ ok: true, v: 2 });
  }
  return out_({ ok: false, error: 'bad_request' });
}

// ---- password ----

function checkPassword_(given) {
  const secret = PropertiesService.getScriptProperties().getProperty('ADMIN_PASSWORD');
  if (!secret) return 'not_configured';
  const cache = CacheService.getScriptCache();
  const fails = Number(cache.get('fails') || 0);
  if (fails >= MAX_FAILS) return 'locked';
  if (safeEqual_(String(given == null ? '' : given), secret)) {
    cache.remove('fails');
    return 'ok';
  }
  cache.put('fails', String(fails + 1), LOCK_SECONDS);
  Utilities.sleep(800);
  return 'bad_password';
}

function safeEqual_(a, b) {
  const n = Math.max(a.length, b.length);
  let diff = a.length ^ b.length;
  for (let i = 0; i < n; i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}

// ---- site storage ----

function readSite_() {
  const cache = CacheService.getScriptCache();
  const hit = cache.get('site');
  if (hit) return JSON.parse(hit);
  const id = PropertiesService.getScriptProperties().getProperty('DATA_FILE_ID');
  if (!id) return null;
  try {
    const text = DriveApp.getFileById(id).getBlob().getDataAsString('UTF-8');
    const data = JSON.parse(text);
    try { if (text.length < 40000) cache.put('site', text, 300); } catch (err) {}
    return data;
  } catch (err) {
    return null;
  }
}

function writeSite_(data) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const props = PropertiesService.getScriptProperties();
    const text = JSON.stringify(data);
    let file = null;
    const id = props.getProperty('DATA_FILE_ID');
    if (id) { try { file = DriveApp.getFileById(id); } catch (err) { file = null; } }
    if (file) file.setContent(text);
    else props.setProperty('DATA_FILE_ID', DriveApp.createFile(DATA_FILE_NAME, text, 'text/plain').getId());
    CacheService.getScriptCache().remove('site');
  } finally {
    lock.releaseLock();
  }
}

// ---- validation - only known fields are stored ----

function str_(v, max, name) {
  if (v == null) return '';
  if (typeof v !== 'string') throw name + ' must be text';
  if (v.length > max) throw name + ' too long';
  return v;
}
function url_(v, name) {
  const s = str_(v, 600, name).trim();
  if (s && !/^https:\/\//i.test(s)) throw name + ' must start with https://';
  return s;
}

function list_(a, max, name, fn) {
  if (a == null) return [];
  if (!Array.isArray(a) || a.length > max) throw name + ' list';
  return a.map(function (r) {
    if (!r || typeof r !== 'object') throw name + ' item';
    return fn(r);
  });
}

function sanitize_(d) {
  if (!d || typeof d !== 'object') throw 'no data';
  if (!Array.isArray(d.books) || d.books.length > 40) throw 'books';
  const g = d.gallery || {}, s = d.story || {}, i = d.info || {}, f = d.footer || {};
  const w = d.writes || {}, n = d.news || {}, v = d.video || {};
  const clean = {
    version: 1,
    info: { title: str_(i.title, 100, 'info.title'), text: str_(i.text, 8000, 'info.text') },
    gallery: { title: str_(g.title, 100, 'gallery.title'), subtitle: str_(g.subtitle, 100, 'gallery.subtitle'),
               url: url_(g.url, 'gallery.url'), feed: url_(g.feed, 'gallery.feed') },
    story: { title: str_(s.title, 100, 'story.title'), subtitle: str_(s.subtitle, 150, 'story.subtitle'), url: url_(s.url, 'story.url') },
    books: d.books.map(function (b, bi) {
      if (!b || !Array.isArray(b.rows) || b.rows.length > 300) throw 'book ' + bi;
      return {
        title: str_(b.title, 100, 'book.title'),
        rows: b.rows.map(function (r) {
          return { name: str_(r.name, 100, 'row.name'), dash: !!r.dash, label: str_(r.label, 150, 'row.label'), url: url_(r.url, 'row.url') };
        })
      };
    }),
    footer: { line1: str_(f.line1, 300, 'footer.line1'), line2: str_(f.line2, 300, 'footer.line2') },
    video: { url: url_(v.url, 'video.url') },
    writes: {
      title: str_(w.title, 100, 'writes.title'), subtitle: str_(w.subtitle, 100, 'writes.subtitle'),
      items: list_(w.items, 500, 'writes', function (r) { return { name: str_(r.name, 100, 'writes.name'), text: str_(r.text, 6000, 'writes.text') }; })
    },
    news: {
      title: str_(n.title, 100, 'news.title'), subtitle: str_(n.subtitle, 100, 'news.subtitle'),
      items: list_(n.items, 300, 'news', function (r) { return { title: str_(r.title, 200, 'news.title'), source: str_(r.source, 100, 'news.source'), url: url_(r.url, 'news.url') }; })
    }
  };
  if (JSON.stringify(clean).length > 400000) throw 'too large';
  return clean;
}

// ---- gallery ----

function gallery_(p) {
  const cache = CacheService.getScriptCache();
  if (!p.refresh) {
    const hit = cache.get('gallery');
    if (hit) return json_(hit);
  }
  const sections = [];
  walk_(DriveApp.getFolderById(FOLDER_ID), '', sections);
  const text = JSON.stringify({
    updated: new Date().toISOString(),
    sections: sections.filter(function (s) { return s.images.length > 0; })
  });
  try { if (text.length < 40000) cache.put('gallery', text, 600); } catch (err) {}
  return json_(text);
}

function byName_(a, b) { return a.name.localeCompare(b.name, 'he', { numeric: true }); }

function walk_(folder, path, sections) {
  const images = [];
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    if (String(f.getMimeType()).indexOf('image/') === 0) images.push({ id: f.getId(), name: f.getName() });
  }
  images.sort(byName_);
  sections.push({ name: path, images: images });
  const subs = [];
  const it = folder.getFolders();
  while (it.hasNext()) { const s = it.next(); subs.push({ name: s.getName(), folder: s }); }
  subs.sort(byName_);
  subs.forEach(function (s) { walk_(s.folder, path ? path + ' / ' + s.name : s.name, sections); });
}

// ---- output ----

function json_(text) { return ContentService.createTextOutput(text).setMimeType(ContentService.MimeType.JSON); }
function out_(obj) { return json_(JSON.stringify(obj)); }
